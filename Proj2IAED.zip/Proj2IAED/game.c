
#include "game.h"


game* create_a_game(char name[], char team1[], char team2[], int score1, int score2)
{ 
    game * new_game = (game*) malloc(sizeof(struct Game));

    new_game->name = (char*) malloc(sizeof(char)*(strlen(name)+1));
    new_game->team1_name = (char*) malloc(sizeof(char)*(strlen(team1)+1));
    new_game->team2_name = (char*) malloc(sizeof(char)*(strlen(team2)+1));
    new_game->next = NULL;
    new_game->in_number = 0;
    
    strcpy(new_game->name, name);
    strcpy(new_game->team1_name, team1);
    strcpy(new_game->team2_name, team2);

    new_game->score1 = score1;
    new_game->score2 = score2;
    
    return new_game;
     
}

void print_game(int line, game* g)
{
    printf("%d %s %s %s %d %d\n",line, g->name, g->team1_name, g->team2_name, g->score1, g->score2);
}

void remove_a_game(game* g)
{
    if(g != NULL)
    {
        free(g->name);
        free(g->team1_name);
        free(g->team2_name);
        free(g);
    }
    
}

void change_the_game_score(game* g, int newScore1, int newScore2)
{
    g->score1 = newScore1;
    g->score2 = newScore2;
}




