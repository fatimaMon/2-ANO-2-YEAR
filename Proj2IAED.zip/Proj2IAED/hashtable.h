#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "game.h"

typedef struct Hashtble
{
    int size;
    int count;
    pgame* table_games;

}*Hashtable, npHash;


Hashtable init_hash_table(int table_size);
pgame insert_hash_table(Hashtable TBL, pgame game);
pgame search_hash_table(Hashtable TBL, char game_name[]);
unsigned long int hash(char *name, int M);
int remove_from_hash(Hashtable TBL, char game_name[]);
int exist_the_game(char game_name[], Hashtable head);
void destroy_games_hash(Hashtable games_table);
void hash_table_to_vector(Hashtable games_hash, pgame vector_game[]);
int compare_teams_ids(pgame game_1, pgame game_2);
void sort_games_in_vector(Hashtable games_hash, pgame* games_vector);
pgame create_a_node_table(char game_name[], char team1_name[], char team2_name[], int score1, int score2);
#endif