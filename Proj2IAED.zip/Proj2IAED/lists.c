
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "lists.h"
#include "hashtable.h"


pgame insert_Begin_List(Hashtable hash_games, pgame game)
{

    int game_index = hash(game->name, hash_games->size);
    game->next = hash_games->table_games[game_index];
    hash_games->table_games[game_index] = game;

    return game;
}

int  is_empty(pgame ngame)
{
    return   ngame == NULL ? naoexiste: existe;
}


int remove_from_list(char game_name[], Hashtable teams_hash)
{
    int game_index ;
    pgame t, prev;

    game_index = hash(game_name, teams_hash->size);

    for(t = teams_hash->table_games[game_index], prev = NULL; t != NULL; prev = t, t = t->next)
    {
        if(strcmp(t->name, game_name) == 0) 
        {
            if(t == teams_hash->table_games[game_index])
                teams_hash->table_games[game_index] = t->next;
            else
                prev->next = t->next;

            remove_a_game(t);
            return 1;   
            break;
        }
    }
    return 0;
   
}

game* find_in_List(char game_name[], Hashtable teams_hash)
{
   pgame temp;
   int head_index;
   head_index = hash(game_name, teams_hash->size);

   for(temp = teams_hash->table_games[head_index]; temp != NULL; temp = temp->next)
   {
       if(strcmp(temp->name, game_name) == 0)
       {
           return temp;
           break;
       }
   }

   return NULL;
    
}


void print_all_list(int line, pgame head)
{
    pgame temp;
    for(temp = head; temp != NULL ; temp = temp->next)
    {
        print_game(line, temp);
    }
}

void free_all(Hashtable games_hash)
{
    pgame temp, aux;
    int i;

    for(i = 0; i < games_hash->size; i++)
    {
        if(games_hash->table_games[i] != NULL)
        {
            temp = games_hash->table_games[i];
            while(temp != NULL)
            {
                aux  = temp;
                temp = temp->next; 
                remove_a_game(aux);
            }
            remove_a_game(temp);
        }
    }
    free(games_hash->table_games);
    free(games_hash);
    
    
}



