#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "command.h"
#include "game.h"
#include "lists.h"
#include "team.h"
#include "hashtable.h"



void command_a(int input_line, Hashtable games_hash_table,Thashtable teams_hash_table)
{
    int score1, score2,  head_index;
    char game_name[1024], team1_name[1024], team2_name[1024];
    pgame new_game;
    pteam team;
    
    input_line++;
    
    getchar();
    scanf("%[^ :]:%[^:]:%[^:]:%d:%d", game_name, team1_name, team2_name, &score1, &score2);
    
    head_index  = hash(game_name, games_hash_table->size);
    
    
    if(search_hash_table(games_hash_table, game_name) == NULL)
    {
        if(already_exists_a_team(team1_name, team2_name, teams_hash_table) == 1)
        {
            
            if(compares_team_wins(score1, score2) > 0)
            {
                team = search_a_team(team1_name, teams_hash_table);
                update_team_wins(team);


            }
            else
            {
                team= search_a_team(team2_name, teams_hash_table);
                update_team_wins(team);
            }
            
            new_game = create_a_game(game_name, team1_name, team2_name, score1, score2);
            games_hash_table->table_games[head_index] = insert_hash_table(games_hash_table, new_game);
            

        }
        else
        {
            printf("%d Equipa inexistente.\n", input_line);
        }
        
    }
    else
    {
        
        printf("%d Jogo existente.\n", input_line);
    }

}


void command_l(int input_line, Hashtable games_hash_table)
{
    int i;
    
    pgame vector_games [games_hash_table->count];
    hash_table_to_vector(games_hash_table, vector_games);
    sort_games_in_vector(games_hash_table, vector_games);

    for( i = 0; i < games_hash_table->count; i++)
    {
        print_game(input_line, vector_games[i]);
    }
}

void command_p(int input_line, Hashtable games_hash_table)
{
    char game_name[1024];
    int head_index;
    pgame found_game;

    getchar();
    scanf("%s", game_name);
    
    found_game = find_in_List(game_name, games_hash_table);
    if(found_game != NULL)
    {
        print_game(input_line, found_game);
    }
    else
    {
        printf("%d Jogo inexistente.\n", input_line);
    }
}

void command_r(int input_line, Hashtable games_hash_table)
{
    char game_name[1024];
    

    getchar();
    scanf("%s", game_name);

    if(remove_from_list(game_name, games_hash_table) == 0)
    {
        printf("%d Jogo inexistente.\n", input_line);
    }
}

void command_s(int input_line, Hashtable games_hash_table)
{
    char game_name[1024];
    int score1, score2;
    pgame game;

    getchar();
    scanf("%[^:]:%d:%d", game_name, &score1, &score2);
    
    game = find_in_List(game_name, games_hash_table);

    if(game != NULL)
    {
        change_the_game_score(game, score1, score2);
    }
    else
    {
        printf("%d Jogo inexistente.\n", input_line);
    }
 
}

void command_A(int input_line, Thashtable teams_hash)
{
    char new_team_name[1024];
    int index_team;

    getchar();
    scanf("%s", new_team_name);

    if(search_a_team(new_team_name, teams_hash) == NULL) /*there is not a team with that name*/
    {
        index_team = team_hash(new_team_name, teams_hash);
        teams_hash->table_teams[index_team] = insert_team(teams_hash, new_team_name);
    }
    else
    {
        printf("%d Equipa existente.\n", input_line);
    }
    
}
void command_P(int input_line, Thashtable teams_hash_table)
{
    char team_name[1024];
    pteam found_team;
 
    getchar();
    scanf("%s", team_name);

    found_team = search_a_team(team_name, teams_hash_table);
    if(found_team != NULL)
    {
        printf("%d %s %d.\n",input_line, found_team->team_name, found_team->vitories_number);
    }
    else
    {
        printf("%d Equipa inexistente.\n", input_line);
    }
    
}
void command_g(int input_line)
{

}

void command_x(int input_line, Thashtable teams_hash_table, Hashtable games_hash_table)
{

    destroy_teams_hash_table(teams_hash_table);
    destroy_games_hash(games_hash_table);
    
    return; 
}


