#include "hashtable.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lists.h"



Hashtable init_hash_table(int table_size)
{
    Hashtable games_hash = (Hashtable) malloc(sizeof(npHash));
    games_hash->table_games = (pgame*) malloc(sizeof(pgame)*table_size);
    games_hash->size = table_size;
    games_hash->count = 0;

    int i;

    for(i = 0; i < table_size; i++)
    {
        games_hash->table_games[i] = NULL;
        
    }

    return games_hash;
}

pgame create_a_node_table(char game_name[], char team1_name[], char team2_name[], int score1, int score2)
{
    pgame new_game = create_a_game(game_name, team1_name, team2_name, score1, score2);
    return new_game;
}

unsigned long int hash(char *str,int  M){ 

	unsigned long int hash = 5381;
    int c;
		while((c=*str++))
			hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

	return hash % M;	
}



pgame insert_hash_table(Hashtable hash_games, pgame game)
{
    hash_games->count++;
    game->in_number = hash_games->count;
    return insert_Begin_List(hash_games, game);
}

pgame search_hash_table(Hashtable TBL, char game_name[])
{
    return find_in_List(game_name, TBL);
}

void destroy_games_hash(Hashtable games_table)
{
    free_all(games_table);
}

int remove_from_hash(Hashtable TBL, char game_name[])
{
    remove_from_list(game_name, TBL);
}

void hash_table_to_vector(Hashtable games_hash, pgame vector_game[])
{
    int i, j = 0;
    pgame temp_game;
    
    for(i = 0; i < games_hash->size; i++)
    {
        for(temp_game = games_hash->table_games[i]; temp_game != NULL; temp_game = temp_game->next)
        {
            vector_game[j++] = temp_game;  
        }
    }  
}

int compare_games_ids(const void* v1, const void* v2)
{
    pgame* game_1_aux  = (pgame*)  v1;
    pgame* game_2_aux  = (pgame*)  v2;

    pgame game_1 = *game_1_aux;
    pgame game_2 = *game_2_aux;


    if(game_1->in_number < game_2->in_number)
        return -1;
    
    else if(game_1->in_number > game_2->in_number)
        return 1;
    
    else 
        return game_1->in_number == game_2->in_number;
}

void sort_games_in_vector(Hashtable games_hash, pgame* games_vector)
{
    qsort(games_vector, games_hash->count, sizeof(pgame), compare_games_ids);
}