#ifndef  GAME
#define  GAME

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 1024

typedef struct Game
{
    char *name;
    char *team1_name;
    char *team2_name;
    int  score1;
    int  score2;
    int in_number;
    struct Game* next;
    
}game, *pgame;

game* create_a_game(char name[], char team1[], char team2[], int score1, int score2);
void print_game(int line, game* g);
void remove_a_game(game *g);
void change_the_game_score(game* g, int newScore, int newScore2);



#endif // ! GAME_H
