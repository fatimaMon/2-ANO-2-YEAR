
#include "team.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



pteam create_a_team(char team_name[])
{
    pteam newTeam = (pteam) malloc(sizeof(team));
    
    newTeam->team_name = (char*) malloc(sizeof(char)*(strlen(team_name)+1));
    
    strcpy(newTeam->team_name, team_name);
    newTeam->vitories_number = 0;
    newTeam->next = NULL;
    
    return newTeam;
}

Thashtable init_teams_hash(int teams_table_size)
{
    int i;
    Thashtable hash_teams = (Thashtable) malloc(sizeof(teamsHash));
    hash_teams->table_teams = (pteam*) malloc(sizeof(pteam)*teams_table_size);
    hash_teams->most_winners_teams = (pteam) malloc(sizeof(team)*teams_table_size);
    hash_teams->size      = teams_table_size;
    hash_teams->count     =  0;


    for( i = 0; i < teams_table_size; i++)
    {
        hash_teams->table_teams[i] = NULL;
    }

    return hash_teams;
}

int team_hash(char name[], Thashtable hash_table)
{
    unsigned long hash = 5381; 
	int c;

	while ((c = *name++))
	    hash = ((hash << 5) + hash) + c; /* hash * 33 + c */ 
	
	return hash%(hash_table->size -1);
}
pteam insert_team(Thashtable hash_table, char team_name[])
{
    pteam newTeam = create_a_team(team_name);
    int position = team_hash(team_name, hash_table);

    newTeam->next = hash_table->table_teams[position];
    hash_table->table_teams[position] = newTeam;

    hash_table->count++;

    return newTeam;

}
void delete_team(Thashtable hashTble, char team_name[])
{
    int position;
    pteam temp, prev;

    prev = NULL;
    position = team_hash(team_name, hashTble);
    temp     = hashTble->table_teams[position];

    while(temp != NULL)
    {
        if(strcmp(temp->team_name, team_name) == 0)
        {
            
            if(temp ==  hashTble->table_teams[position])
            {
                hashTble->table_teams[position] = temp->next;
                
            }
            else
            {
                prev->next = temp->next;
            }

            free_team(temp);
            break;
        }

        prev = temp;
        temp = temp->next;
        
    }
}

pteam search_a_team(char team_name[], Thashtable hash_table)
{
    pteam temp;
    int position;

    position = team_hash(team_name, hash_table);
    temp     = hash_table->table_teams[position];

    
    while(temp != NULL)
    {
        if(compare_teams_names(team_name, temp->team_name) == 0)
        {
            return temp;
            break;
        }
        temp = temp->next;
    }

    return NULL;
}

int already_exists_a_team(char team1[], char team2[], Thashtable hash_table)
{
    
    if(search_a_team(team1, hash_table) == NULL || search_a_team(team2, hash_table) == NULL)
    {
        return 0;
    }

    return 1;
}

void free_team(pteam team)
{
    if(team != NULL)
    {
        free(team->team_name);
        free(team);
    }
    
}

void  print_team(pteam team)
{
    printf("%s %d\n",team->team_name, team->vitories_number);
}

void destroy_teams_hash_table(Thashtable teams_hash_table)
{
    int table_size = teams_hash_table->size, i;
    pteam temp, aux;

    for( i = 0; i < table_size; i++)
    {
        if(teams_hash_table->table_teams[i] != NULL)
        {
            temp = teams_hash_table->table_teams[i];
            while(temp != NULL)
            {
                aux  = temp;
                temp = temp->next; 
                free_team(aux);
            }
            free_team(temp);
        }
    }
    free(teams_hash_table->table_teams);
    free(teams_hash_table->most_winners_teams);
    free(teams_hash_table);
    

}

int compare_teams_names(char team_1[], char team_2[])
{
    return strcmp(team_1, team_2) == 0 ? 0:1;
}

void update_team_wins(pteam team)
{
    team->vitories_number++;
}

pteam get_most_winners_teams(Thashtable table)
{

}

int compares_team_wins(int first_team, int second_team)
{
    return (first_team - second_team);
}

void  sort_team_vector(pteam vector, int elms_count)
{

}
