#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lists.h"
#include "game.h"
#include "hashtable.h"
#include "team.h"
#include "command.h"

/*================================================
Nome: Fátima Napoleão
Nº 91605
Projeto 2 -IAED: 25/05/2020
=================================================*/


/*main fuction*/
int main(int argc, char* argv[])
{
    char command; 
    int input_line = 0, table_size = 500;

    Hashtable games_hash_table  = init_hash_table(table_size); 
    Thashtable teams_hash_table = init_teams_hash(table_size);
    
    while(1){
        command = getchar();
        switch (command)
        {

        case 'a':
            input_line++;
            command_a(input_line, games_hash_table, teams_hash_table);
            break;
        case 'l':
            input_line++;
            command_l(input_line, games_hash_table);
            break;
        
        case 'p':
            input_line++;
            command_p(input_line, games_hash_table);
            break;
        
        case 'r':
            input_line++;
            command_r(input_line, games_hash_table);
            break;
        
        case 's':
            input_line++;
            command_s(input_line, games_hash_table);
            break;
        
        case 'A':
            input_line++;
            command_A(input_line, teams_hash_table);
            break;
        
        case 'P':
            input_line++;
            command_P(input_line, teams_hash_table);
            break;
        
        case 'g':
            input_line++;
            command_g(input_line);
            break;
        
        case 'x':
            input_line++;
            command_x(input_line, teams_hash_table, games_hash_table);
            return EXIT_SUCCESS;
            break;
        
        default:
            break;
        }
    }

    
}