#ifndef TEAM_H
#define TEAM_H


typedef struct Team
{
    char *team_name;
    int vitories_number;
    struct Team* next;
    
}team, *pteam;

typedef struct Team_hash_table
{
    pteam* table_teams;
    int size;
    int count;
    pteam most_winners_teams;

}*Thashtable, teamsHash;


Thashtable init_teams_hash(int teams_table_size);
pteam create_a_team(char team_name[]);
pteam get_most_winners_teams(Thashtable table);
pteam insert_team(Thashtable hash_table, char team_name[]);
void  delete_team(Thashtable hashTable, char team_name[]);
void  print_team(pteam team);
int   compares_team_wins(int first_team, int second_team);
void  sort_team_vector(pteam vector, int elms_count);
pteam search_a_team(char team_name[], Thashtable hash_table);
int team_hash(char name[], Thashtable hash_table);
void free_team(pteam team);
int compare_teams_names(char team_1[], char team_2[]);
void update_team_wins(pteam team);
int already_exists_a_team(char team1[], char team2[], Thashtable hash);
void destroy_teams_hash_table(Thashtable teams_hash_table);
#endif // !TEAM_H
