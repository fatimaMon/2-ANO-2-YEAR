#ifndef COMMMAND_H
#define COMMAND_H

#include "hashtable.h"
#include "team.h"

/* commands of the program*/
void command_a(int input_line, Hashtable games_hash_table, Thashtable teams_hash_table);
void command_l(int input_line, Hashtable games_hash_table);
void command_p(int input_line, Hashtable games_hash_table);
void command_r(int input_line, Hashtable games_hash_table);
void command_s(int input_line, Hashtable games_hash_table);
void command_A(int input_line, Thashtable teams_hash);
void command_P(int input_line, Thashtable teams_hash);
void command_g(int input_line);
void command_x(int input_line, Thashtable teams_hash_table, Hashtable games_hash_table);


#endif // !COMMMAND_H
            