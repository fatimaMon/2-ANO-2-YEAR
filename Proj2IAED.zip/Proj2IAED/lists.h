#ifndef LISTS_H
#define LISTS_H

#include "hashtable.h"

#define existe 1
#define naoexiste 0


/*Prototypes*/
pgame insert_Begin_List(Hashtable hash_games, pgame game);
int remove_from_list(char game_name[], Hashtable head);
game* find_in_List(char game_name[], Hashtable head);
void free_all(Hashtable games_hash);
int  is_empty(pgame game);
void print_all_list(int line, pgame head);
void increment_counter(Hashtable temp);

#endif // !LISTS_H

